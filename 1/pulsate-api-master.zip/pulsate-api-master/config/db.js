module.exports = {
    url : "mongodb://sameeriqbal:tailung12@ds135956.mlab.com:35956/pulsate"
}